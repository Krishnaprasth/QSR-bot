
# QSR CEO Bot

Streamlit-based financial analysis bot for Quick Service Restaurant performance tracking.

## Features
- Metric calculations
- Cohort analysis
- Scenario simulations
- Natural language query support
